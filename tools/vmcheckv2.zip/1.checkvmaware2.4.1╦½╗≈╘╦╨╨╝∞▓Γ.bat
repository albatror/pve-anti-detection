vmaware_debug2.4.1.exe
pause