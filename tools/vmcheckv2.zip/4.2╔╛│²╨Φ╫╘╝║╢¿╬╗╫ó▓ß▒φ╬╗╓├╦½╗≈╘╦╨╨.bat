@echo off
%1 mshta vbscript:CreateObject("Shell.Application").ShellExecute("cmd.exe","/c %~s0 ::","","runas",1)(window.close)&&exit
echo run admin!
cd /d "%~dp0"
PsExec.exe -s -i -d regedit.exe